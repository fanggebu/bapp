package com.pa;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.SynchronousQueue;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

//51ְλ��Ϣ
public class KaoCe {
	
	public static void main(String[] args) throws IOException {
		Scanner sc = new Scanner(System.in);
		for(int j=0;j<10;j++){
			System.out.println("�����룺");
			String url = sc.next();
			
			Document doc = Jsoup.connect(url).get();
			
			Elements e = doc.getElementsByClass("bmsg job_msg inbox");
			
//			List<String> p = e.tagName("p").eachText();
			
			List<String> sd = e.get(0).getElementsByTag("p").eachText();
			
			File f = new File("C:/Users/Samsung/Desktop/ְλ.txt");
			int s = sd.size();
			for(int i=0;i<s;i++){
				String str = sd.get(i)+"\n";
				byte[] bytes = str.getBytes();                           //ת��Ϊ�ֽ�����
				
				 RandomAccessFile randomFile2 = new RandomAccessFile(f, "rw");
		         // �ļ����ȣ��ֽ���
		         long fileLength = randomFile2.length();
		         //��д�ļ�ָ���Ƶ��ļ�β��
		         randomFile2.seek(fileLength);
		         randomFile2.write(bytes);
		         randomFile2.close();
		         
			}
			
			System.out.println("���");	
		}
	}

}
